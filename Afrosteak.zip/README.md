# Afrosteaky

A very exciting project I worked on. Thanks to the owner, my friend Ojo E. for the privilege. 


/* 
   Images gotten from pexels.com
   Design inspiration from dribble.com and pinterest.com
*/

The site is live on afrosteak.netlify.app
